import React from "react";

const MainSlide = () => {
  return <div></div>;
};

export default MainSlide;
