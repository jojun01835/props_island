import React from "react";

const MdPick = () => {
  return <div></div>;
};

export default MdPick;
