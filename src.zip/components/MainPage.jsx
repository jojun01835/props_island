import React from "react";
import Header from "./Header";
import MainSlide from "./MainSlide";
import MdPick from "./MdPick";
import Footer from "./Footer";
import Magazine from "./Magazine";

const MainPage = () => {
  return (
    <div>
      <Header />
      <MainSlide />
      <MdPick />
      <Magazine />
      <Footer />
    </div>
  );
};

export default MainPage;
