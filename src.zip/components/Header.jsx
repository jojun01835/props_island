import { AiOutlineDownload } from "react-icons/ai";
import React from "react";
import { Link } from "react-router-dom";
import styles from "./Header.module.scss";
import logo from "../img/logo.png";
import NavBar from "./NavBar";

const Header = () => {
  return (
    <header className={styles.header}>
      <h1>
        <Link to="/">
          <img src={logo} alt="로고" />
          <NavBar />
          <button>
            <AiOutlineDownload />
          </button>
        </Link>
      </h1>
    </header>
  );
};

export default Header;
