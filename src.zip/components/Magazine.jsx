import React from "react";

const Magazine = () => {
  return <div></div>;
};

export default Magazine;
