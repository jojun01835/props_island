import React from "react";

const Cook = () => {
  return <div></div>;
};

export default Cook;
