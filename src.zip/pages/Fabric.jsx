import React from "react";

const Fabric = () => {
  return <div></div>;
};

export default Fabric;
