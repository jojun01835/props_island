import React from "react";

const Office = () => {
  return <div></div>;
};

export default Office;
