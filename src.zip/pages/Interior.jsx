import React from "react";

const Interior = () => {
  return (
    <div>
      <h2>Interior</h2>
    </div>
  );
};

export default Interior;
